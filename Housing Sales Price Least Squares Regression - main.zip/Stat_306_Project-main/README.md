# Stat_306_Project
 Course Project for Stat 306

## Code Structure:
The code used in this project are in the src folder.

clearning.R cleans the data, and save the cleaned data as a parquet.

feature_engineering.R performs log transformations and creates new variables.

model_selection.R selects the best model

training.R is where cross-validation happens and MSE is calculated

visualization.R is a script file where we generated some of the plots. 

## Participation from group members:

Every group member contributed equally to this project. 

We peer-programmed most of the code together, and wrote the report together. 

